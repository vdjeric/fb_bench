if (self.CavalryLogger) { CavalryLogger.start_js(["umUWd"]); }

__d('AYMTHomepagePanelLogger',['BanzaiLogger','Event','tidyEvent'],(function a(b,c,d,e,f,g){var h=null,i={init:function j(k,l){c('tidyEvent')(c('Event').listen(k,'click',function(event){c('BanzaiLogger').log('AYMTHomepagePanelLoggerConfig',l);}));}};f.exports=i;}),null);