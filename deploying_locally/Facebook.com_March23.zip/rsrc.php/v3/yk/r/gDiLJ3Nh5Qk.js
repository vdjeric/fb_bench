if (self.CavalryLogger) { CavalryLogger.start_js(["\/k6Sq"]); }

__d('CornerEnum',['React'],(function a(b,c,d,e,f,g){'use strict';var h=c('React').PropTypes,i={topLeft:'topLeft',topRight:'topRight',bottomRight:'bottomRight',bottomLeft:'bottomLeft',propType:h.oneOf(['topLeft','topRight','bottomRight','bottomLeft']),values:['topLeft','topRight','bottomRight','bottomLeft']};f.exports=i;}),null);