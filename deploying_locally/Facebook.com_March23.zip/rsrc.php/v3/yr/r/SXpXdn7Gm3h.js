if (self.CavalryLogger) { CavalryLogger.start_js(["ejvfu"]); }

__d("BoostedAutomatedAdsDialogUIStoreFields",[],(function a(b,c,d,e,f,g){f.exports={ACTIVE_AUTOMATED_ADS_DIALOG_TAB:"active_automated_ads_dialog_tab",ACTIVE_AUTOMATED_ADS_INSIGHTS_GRAPHS_TAB:"active_automated_ads_insights_graphs_tab"};}),null);