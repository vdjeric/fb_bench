if (self.CavalryLogger) { CavalryLogger.start_js(["PCXMF"]); }

__d("AdsCouponPromotionError",[],(function a(b,c,d,e,f,g){f.exports={ALREADY_CLAIMED:"already_claimed"};}),null);