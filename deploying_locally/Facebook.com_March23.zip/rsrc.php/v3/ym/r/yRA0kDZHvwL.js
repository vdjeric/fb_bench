if (self.CavalryLogger) { CavalryLogger.start_js(["kftge"]); }

__d('SpatialReactionAnimationConfig',[],(function a(b,c,d,e,f,g){'use strict';var h=60,i={SHADOW:{COLOR:'rgba(0, 0, 0, 0.5)',BLUR:60},SIZES:{FULL_SIZE:{PX:38}},OPACITY:{FADE_IN_DURATION:{SECONDS:.5,FRAMES:.5*h},DISPLAY_DURATION:{SECONDS:1,FRAMES:1*h},FADE_OUT_DURATION:{SECONDS:.3,FRAMES:.3*h},MAX:1,MIN:0}};f.exports=i;}),null);